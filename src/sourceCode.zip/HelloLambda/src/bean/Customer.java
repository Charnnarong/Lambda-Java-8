package bean;

import java.util.List;

public class Customer
{
	int id;
	String name;
	List<Integer> demands;
	
	
	
	public List<Integer> getDemands()
	{
		return demands;
	}
	public void setDemands(List<Integer> demands)
	{
		this.demands = demands;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public List<Product> getProduce()
	{
		return produce;
	}
	public void setProduce(List<Product> produce)
	{
		this.produce = produce;
	}
	List<Product> produce;

}
