package main;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class application
{

	public static void main(String[] args)
	{

		List<String> names = Arrays.asList("a", "c", "b", "z", "x", "y");

		// names.forEach(name -> System.out.println(name));

		List<String> num = Arrays.asList("1","2","3");		
		String minString = Stream.of(names,num).flatMap(c -> c.stream()).min(Comparator.comparing(c -> c)).get();	
		String maxString = Stream.of(names,num).flatMap(c -> c.stream()).max(Comparator.comparing(c -> c)).get();
		System.out.println(minString + " : " + maxString);
	}

}
