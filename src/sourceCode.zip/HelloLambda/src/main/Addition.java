package main;

public interface Addition
{
	public int addTwoNumber(int a, int b);

}
