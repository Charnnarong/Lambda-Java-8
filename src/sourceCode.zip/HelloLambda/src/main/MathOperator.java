package main;

public interface MathOperator<T>
{	
	public T apply(T a, T b);

}
