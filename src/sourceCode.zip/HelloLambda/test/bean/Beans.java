package bean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;


/**
 * @author Charnnarong Cth
 *
 */
public class Beans
{
	List<Company> companies = null;
	List<Customer> customers = null;

	@Before
	public void init()
	{
		companies = new ArrayList<>();
		customers = new ArrayList<>();
		Random rand = new Random();
		for (int companyId = 0; companyId < 10; companyId++)
		{
			Company newCompany = new Company();
			newCompany.setId(companyId);
			List<Product> newProducts = new ArrayList<Product>(100);
			for (int i = 0; i < 100; i++)
			{
				Product p = new Product();
				p.setId(i);
				p.setPrice(Math.random() * 100);
				newProducts.add(p);
			}
			newCompany.setProducts(newProducts);
			companies.add(newCompany);
		}

		for (int customerId = 0; customerId < 5; customerId++)
		{
			Customer newCustomer = new Customer();
			newCustomer.setId(customerId);
			int numberOfItem = rand.nextInt(100) + 1;
			List<Integer> demands = new ArrayList<>(numberOfItem);
			for (int i = 0; i < numberOfItem; i++)
			{
				demands.add(i);
			}
			newCustomer.setDemands(demands);
			customers.add(newCustomer);

		}

	}

	@Test
	public void testShowCase()
	{
		Map<Customer, Double> leastCost = new HashMap<>();
		for (Customer customer : customers)
		{
			double totalCost = 0;
			for (Integer productId : customer.getDemands())
			{
				double minCost = Double.MAX_VALUE;
				for (Company company : companies)
				{
					for (Product offer : company.getProducts())
					{
						if (offer.getId() == productId)
						{
							if (offer.getPrice() < minCost)
							{
								minCost = offer.getPrice();
							}
						}
					}
				}
				totalCost += minCost;
			}
			leastCost.put(customer, totalCost);
		}

		Map<Customer, Double> leastCostLambda =
				customers
				.stream()
				.collect(
						Collectors.toMap(
								Function.identity(), 
								customer -> customer
											.getDemands()
											.stream()
											.mapToDouble(
													productId -> companies
															.stream()
															.flatMap(cmp -> cmp.getProducts().stream())
															.filter(offer -> offer.getId() == productId)
															.min(Comparator.comparing(offer -> offer.getPrice()))
															.get().getPrice())
											.sum()));

		System.out.println("---Show case s--- ");
		for (Customer c : leastCost.keySet())
		{
			for (Customer cl : leastCostLambda.keySet())
			{
				if (c.getId() == cl.getId())
				{
					assertEquals(leastCost.get(cl), leastCostLambda.get(cl),
							0.00001);
				}
			}
		}

	}

	@Test
	public void test()
	{
		Map<Customer, Double> leastCost = new HashMap<>();
		for (Customer customer : customers)
		{
			double totalCost = 0;
			for (Integer productId : customer.getDemands())
			{
				double minCost = Double.MAX_VALUE;
				for (Company company : companies)
				{
					for (Product offer : company.getProducts())
					{
						if (offer.getId() == productId)
						{
							if (offer.getPrice() < minCost)
							{
								minCost = offer.getPrice();
							}
						}
					}
				}
				totalCost += minCost;
			}
			leastCost.put(customer, totalCost);
		}

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		assertTrue(true);
	}

	@Test
	public void lambda1()
	{
		System.out.println("---Lambda---");
		Map<Customer, Double> leastCost = new HashMap<>();
		for (Customer customer : customers)
		{
			double totalCost = 0;
			for (Integer productId : customer.getDemands())
			{
				double minCost = Double.MAX_VALUE;
				for (Company company : companies)
				{

					minCost = company
							.getProducts()
							.stream()
							.filter(offer -> offer.getId() == productId)
							.min(Comparator.comparing(offer -> offer.getPrice()))
							.get().getPrice();
				}
				totalCost += minCost;
			}
			leastCost.put(customer, totalCost);
		}

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		System.out.println("---Lambda---");
	}

	@Test
	public void lambda2()
	{
		System.out.println("---Lambda---");
		Map<Customer, Double> leastCost = new HashMap<>();
		for (Customer customer : customers)
		{
			double totalCost = 0;
			for (Integer productId : customer.getDemands())
			{
				double minCost = Double.MAX_VALUE;
				//
				minCost = companies.stream()
						.flatMap(cmp -> cmp.getProducts().stream())
						.filter(offer -> offer.getId() == productId)
						.min(Comparator.comparing(offer -> offer.getPrice()))
						.get().getPrice();
				//
				totalCost += minCost;
			}
			leastCost.put(customer, totalCost);
		}

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		System.out.println("---Lambda---");
	}

	@Test
	public void lambda3()
	{
		System.out.println("---Lambda---");
		Map<Customer, Double> leastCost = new HashMap<>();
		for (Customer customer : customers)
		{
			double totalCost = customer
					.getDemands()
					.stream()
					.mapToDouble(
							productId -> companies
									.stream()
									.flatMap(cmp -> cmp.getProducts().stream())
									.filter(offer -> offer.getId() == productId)
									.min(Comparator.comparing(offer -> offer
											.getPrice())).get().getPrice())
					.sum();

			leastCost.put(customer, totalCost);
		}

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		System.out.println("---Lambda---");
	}

	@Test
	public void lambda4()
	{
		System.out.println("---Lambda 4s---");
		Map<Customer, Double> leastCost = new HashMap<>();
		// for (Customer customer : customers)
		// {
		List<Double> l = customers
				.stream()
				.map(customer -> customer
						.getDemands()
						.stream()
						.mapToDouble(
								productId -> companies
										.stream()
										.flatMap(
												cmp -> cmp.getProducts()
														.stream())
										.filter(offer -> offer.getId() == productId)
										.min(Comparator
												.comparing(offer -> offer
														.getPrice())).get()
										.getPrice()).sum())
				.collect(Collectors.toList());

		// leastCost.put(customer, totalCost);
		// }

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}
		l.forEach(x -> System.out.println(x));

		System.out.println("---Lambda 4e---");
	}

	@Test
	public void lambda5()
	{
		System.out.println("---Lambda 5 s---");
		Map<Customer, Double> leastCost = new HashMap<>();
		// for (Customer customer : customers)
		// {
		leastCost = customers
				.stream()
				.collect(
						Collectors.toMap(
								Function.identity(),
								customer -> customer
										.getDemands()
										.stream()
										.mapToDouble(
												productId -> companies
														.stream()
														.flatMap(
																cmp -> cmp
																		.getProducts()
																		.stream())
														.filter(offer -> offer
																.getId() == productId)
														.min(Comparator
																.comparing(offer -> offer
																		.getPrice()))
														.get().getPrice())
										.sum()));

		// leastCost.put(customer, totalCost);
		// }

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		System.out.println("---Lambda 5 e---");
	}

	@Test
	public void test6()
	{
		System.out.println("---test 6 s----");
		Map<Company, Integer> x = companies.stream().collect(
				Collectors.toMap(Function.identity(), c -> c.getId()));

		for (Company c : x.keySet())
		{
			System.out.println(c.getId() + " == " + x.get(c));
		}
		System.out.println("---test 6 e----");
	}
	
	@Test
	public void test7()
	{
		System.out.println("---Lambda 7 s---");
		Map<Customer, Double> leastCost =
				customers
				.parallelStream()
				.collect(
						Collectors.toMap(
								Function.identity(), 
								customer -> customer
											.getDemands()
											.stream()
											.mapToDouble(
													productId -> companies
															.stream()
															.flatMap(cmp -> cmp.getProducts().stream())
															.filter(offer -> offer.getId() == productId)
															.min(Comparator.comparing(offer -> offer.getPrice()))
															.get().getPrice())
											.sum()));

		

		for (Customer c : leastCost.keySet())
		{
			System.out.println(c.getId() + " : " + leastCost.get(c));
		}

		System.out.println("---Lambda 7 e---");
	}


}
