package main;

import java.util.HashMap;
import java.util.Map;

import server.Lenghty;
import server.LengthyBuilder;

public class Application
{

	public static void main(String args[])
	{
		int number = 2;
		Double weight = 5.6;
		Double length = 7.1;
		String name = "Charnnarong";
		char symbol = 'K';
		Map<String, Double> misc = new HashMap<>();
		misc.put("M", 0.2);
		misc.put("K", 0.3);

		Lenghty lenghty = new Lenghty(number, weight, length, name, symbol,
				misc);

		lenghty.showParam();
		
		System.out.println("-----Created by Intellisense Builder Pattern---");
		Lenghty.ParamInjector injector = new LengthyBuilder().begin()
				.setNumber(8).setWeight(weight).setLength(length)
				.setName(name).setSymbol('H').setMisc(misc).build();
		
		Lenghty lenghty2 = new Lenghty(injector);
		lenghty2.showParam();

	}

}
