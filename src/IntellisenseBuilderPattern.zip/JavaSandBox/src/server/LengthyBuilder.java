package server;

import java.util.Map;

import server.Lenghty.Begin;
import server.Lenghty.Build;
import server.Lenghty.ParamInjector;
import server.Lenghty.SetLength;
import server.Lenghty.SetMisc;
import server.Lenghty.SetName;
import server.Lenghty.SetNumber;
import server.Lenghty.SetSymbol;
import server.Lenghty.SetWeight;

public class LengthyBuilder implements ParamInjector, Begin, SetName,
		SetWeight, SetLength, SetSymbol, SetNumber, SetMisc, Build
{
	private int number;
	private Double weight;
	private Double length;
	private String name;
	private char symbol;
	private Map<String, Double> misc;
	
	
	@Override
	public ParamInjector build()
	{		
		return this;
	}
	@Override
	public Build setMisc(Map<String, Double> misc)
	{
		this.misc = misc;
		return this;
	}
	@Override
	public SetWeight setNumber(int number)
	{
		this.number = number;
		return this;
	}
	@Override
	public SetMisc setSymbol(char symbol)
	{
		this.symbol = symbol;
		return this;
	}
	@Override
	public SetName setLength(Double length)
	{
		this.length = length;
		return this;
	}
	@Override
	public SetLength setWeight(Double weight)
	{
		this.weight = weight;
		return this;
	}
	@Override
	public SetSymbol setName(String name)
	{
		this.name = name;
		return this;
	}
	@Override
	public SetNumber begin()
	{
		return this;
	}
	@Override
	public int getNumber()
	{
		return number;
	}
	@Override
	public Double getWeight()
	{
		return weight;
	}
	@Override
	public Double getLength()
	{
		return length;
	}
	@Override
	public String getName()
	{
		return name;
	}
	@Override
	public char getSymbol()
	{
		return symbol;
	}
	@Override
	public Map<String, Double> getMisc()
	{
		return misc;
	}

	
}
