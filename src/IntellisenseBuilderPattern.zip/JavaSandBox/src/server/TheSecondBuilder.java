package server;

import server.TheSecond.Build;
import server.TheSecond.ParamInjector;
import server.TheSecond.SetA;
import server.TheSecond.SetB;
import server.TheSecond.SetC;
import server.TheSecond.SetD;

public class TheSecondBuilder implements TheSecond.Begin , TheSecond.SetA , TheSecond.SetB , TheSecond.SetC,TheSecond.SetD,TheSecond.Build,TheSecond.ParamInjector
{

	int a;
	Double b;
	String c;
	char d;
	
	@Override
	public int getA()
	{
		return a;
	}

	@Override
	public Double getB()
	{
		return b;
	}

	@Override
	public String getC()
	{
		return c;
	}

	@Override
	public char getD()
	{
		return d;
	}

	@Override
	public ParamInjector build()
	{
		return this;
	}

	@Override
	public Build setD(char d)
	{
		this.d =d;
		return this;
	}

	@Override
	public SetD setC(String c)
	{
		this.c = c;
		return this;
	}

	@Override
	public SetC setB(Double b)
	{
		this.b = b;
		return this;
	}

	@Override
	public SetB setA(int a)
	{
		this.a = a;
		return this;
	}

	@Override
	public SetA begin()
	{
		return this;
	}

}
