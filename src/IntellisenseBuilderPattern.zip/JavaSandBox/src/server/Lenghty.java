package server;

import java.util.Map;
import java.util.Map.Entry;

public class Lenghty
{
	private int number;
	private Double weight;
	private Double length;
	private String name;
	private char symbol;
	private Map<String, Double> misc;

	public interface Begin
	{
		SetNumber begin();
	}

	public interface SetNumber
	{
		SetWeight setNumber(int number);
	}

	public interface SetWeight
	{
		SetLength setWeight(Double weight);
	}

	public interface SetLength
	{
		SetName setLength(Double length);
	}

	public interface SetName
	{
		SetSymbol setName(String name);
	}

	public interface SetSymbol
	{
		SetMisc setSymbol(char symbol);
	}

	public interface SetMisc
	{
		Build setMisc(Map<String, Double> misc);
	}

	public interface Build
	{
		ParamInjector build();
	}

	public interface ParamInjector
	{
		int getNumber();

		Double getWeight();

		Double getLength();

		String getName();

		char getSymbol();

		Map<String, Double> getMisc();
	}

	public Lenghty(int number, Double weight, Double length, String name,
			char symbol, Map<String, Double> misc)
	{
		this.number = number;
		this.weight = weight;
		this.length = length;
		this.name = name;
		this.symbol = symbol;
		this.misc = misc;
	}

	public Lenghty(ParamInjector injector)
	{
		this.number = injector.getNumber();
		this.weight = injector.getWeight();
		this.length = injector.getLength();
		this.name = injector.getName();
		this.symbol = injector.getSymbol();
		this.misc = injector.getMisc();
	}

	public void showParam()
	{
		System.out.println(number);
		System.out.println(weight);
		System.out.println(length);
		System.out.println(name);
		System.out.println(symbol);
		for (Entry<String, Double> item : misc.entrySet())
		{
			System.out.println(item.getKey() + " : " + item.getValue());
		}

	}

}
