package server;


public class TheSecond
{

	public static interface Begin
	{
		SetA begin();
	}
	
	public static interface SetA
	{
		SetB setA(int a);
	}

	public static interface SetB
	{
		SetC setB(Double b);
	};

	public static interface SetC
	{
		SetD setC(String c);
	};

	public static interface SetD
	{
		Build setD(char d);
	};
	
	public static interface Build
	{
		ParamInjector build();		
	}	
	
	public static interface ParamInjector
	{

		int getA();

		Double getB();

		String getC();

		char getD();

	}

	
	
	int a;
	Double b;
	String c;
	char d;
	
	public TheSecond(int a, Double b, String c, char d)
	{
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}
	
	public TheSecond(ParamInjector injector)
	{
		
		this.a = injector.getA();
		this.b = injector.getB();
		this.c = injector.getC();
		this.d = injector.getD();
	}

	public void showParam()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
